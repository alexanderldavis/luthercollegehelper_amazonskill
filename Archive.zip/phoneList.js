module.exports = {
	"career center": "563, 387, 1025",
	"counseling services": "563, 387, 1375",
	"financial aid": "563, 387, 1018",
	"health services": "563, 387, 1045",
	"registrar": "563, 387, 1167",
	"residence life": "563, 387, 1330",
	"SASC": "563, 387, 1270",
	"security": "563, 387, 2111",
	"student life": "563, 387, 1020",
	"technology help desk": "563, 387, 1000",
	"help desk": "563, 387, 1000",
	"ticket office": "563, 387, 1357",
	"counseling": "563, 387, 1375",
	"welcome desk": "563, 387, 1111"
};